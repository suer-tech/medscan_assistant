import React, { useState, useMemo } from "react";
import { 
  History, Plus, Menu, Search, FileText, ChevronRight, Eye, Bone, 
  Brain, Activity, Upload, CheckCircle2, Clock, AlertTriangle, 
  AlertCircle, Trash2, ArrowUpDown, LayoutTemplate, ScanEye,
  FolderOpen
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { Button } from "./components/ui/button";
import { Input } from "./components/ui/input";
import { Card, CardContent } from "./components/ui/card";
import { Sheet, SheetContent, SheetTrigger } from "./components/ui/sheet";
import { Badge } from "./components/ui/badge";
import { ScrollArea } from "./components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./components/ui/select";

type Priority = 'critical' | 'warning' | 'normal';
type Status = 'awaiting' | 'progress' | 'approved';

interface HistoryItem {
  id: number;
  title: string;
  dateIso: string;
  displayDate: string;
  type: string;
  status: Status;
  priority: Priority;
}

const INITIAL_HISTORY: HistoryItem[] = [
  { id: 1, title: "МРТ Головного мозга", displayDate: "Сегодня, 10:45", dateIso: "2026-05-12T10:45:00", type: "brain", status: "awaiting", priority: "critical" },
  { id: 2, title: "Рентген грудной клетки", displayDate: "Вчера, 15:20", dateIso: "2026-05-11T15:20:00", type: "lungs", status: "approved", priority: "normal" },
  { id: 3, title: "КТ Коленного сустава", displayDate: "10 Мая, 09:15", dateIso: "2026-05-10T09:15:00", type: "bone", status: "progress", priority: "warning" },
  { id: 4, title: "ОКТ Сетчатки", displayDate: "08 Мая, 14:00", dateIso: "2026-05-08T14:00:00", type: "eye", status: "approved", priority: "normal" },
  { id: 5, title: "МРТ Шейного отдела", displayDate: "05 Мая, 11:30", dateIso: "2026-05-05T11:30:00", type: "bone", status: "awaiting", priority: "warning" },
];

const STATUS_MAP: Record<Status, { label: string; color: string; icon: any }> = {
  awaiting: { label: "Ожидает", color: "text-slate-600 bg-slate-100 border-slate-200", icon: Clock },
  progress: { label: "В работе", color: "text-amber-600 bg-amber-50 border-amber-200", icon: Activity },
  approved: { label: "Утверждено", color: "text-emerald-600 bg-emerald-50 border-emerald-200", icon: CheckCircle2 },
};

const PRIORITY_MAP: Record<Priority, { label: string; border: string; text: string; dot: string }> = {
  critical: { label: "Критический", border: "border-l-red-500", text: "text-red-600", dot: "bg-red-500" },
  warning: { label: "Внимание", border: "border-l-orange-500", text: "text-orange-600", dot: "bg-orange-500" },
  normal: { label: "Норма", border: "border-l-emerald-500", text: "text-emerald-600", dot: "bg-emerald-500" },
};

// Custom Lungs Icon
const LungsIcon = ({ className }: { className?: string }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
  >
    <path d="M12 2v5" />
    <path d="M11.5 7C7.5 5 4 6.5 4 11s2 8 4 8 3.5-3.5 3.5-3.5V7Z" />
    <path d="M12.5 7C16.5 5 20 6.5 20 11s-2 8-4 8-3.5-3.5-3.5-3.5V7Z" />
  </svg>
);

export type Category = {
  id: string;
  name: string;
  desc?: string;
  icon?: any;
  children?: Category[];
};

const ORGANS: Category[] = [
  { id: "brain", name: "Головной мозг", desc: "МРТ / КТ", icon: Brain },
  { id: "lungs", name: "Легкие", desc: "Рентген / КТ", icon: LungsIcon },
  { id: "bone", name: "Опорно-двигательный аппарат", desc: "Рентген / КТ / МРТ", icon: Bone },
  { 
    id: "eye", 
    name: "Органы зрения", 
    desc: "ОКТ Сетчатки", 
    icon: Eye,
    children: [
      {
        id: "eye_fundus",
        name: "Офтальмология (глазное дно)",
        desc: "Анализ снимков глазного дна",
        icon: FolderOpen,
      },
      {
        id: "eye_template",
        name: "Запрос по шаблону",
        desc: "Стандартизированные исследования",
        icon: LayoutTemplate,
        children: [
          {
            id: "eye_oct",
            name: "OCT-снимок",
            desc: "Оптическая когерентная томография",
            icon: ScanEye,
          }
        ]
      }
    ]
  },
];

function HistoryPanel({ 
  history, 
  onDelete, 
  sortOrder, 
  setSortOrder 
}: { 
  history: HistoryItem[], 
  onDelete: (id: number) => void, 
  sortOrder: string, 
  setSortOrder: (v: string) => void 
}) {
  const [search, setSearch] = useState("");

  const sortedHistory = useMemo(() => {
    const filtered = history.filter(h => h.title.toLowerCase().includes(search.toLowerCase()));
    return filtered.sort((a, b) => {
      if (sortOrder === 'newest') {
        return new Date(b.dateIso).getTime() - new Date(a.dateIso).getTime();
      } else if (sortOrder === 'oldest') {
        return new Date(a.dateIso).getTime() - new Date(b.dateIso).getTime();
      } else if (sortOrder === 'priority') {
        const priorityWeight = { critical: 3, warning: 2, normal: 1 };
        const diff = priorityWeight[b.priority] - priorityWeight[a.priority];
        if (diff !== 0) return diff;
        return new Date(b.dateIso).getTime() - new Date(a.dateIso).getTime();
      }
      return 0;
    });
  }, [history, search, sortOrder]);

  return (
    <div className="flex flex-col h-full bg-slate-50 border-r border-slate-200">
      <div className="p-4 border-b border-slate-200 bg-white space-y-4 shrink-0">
        <h2 className="text-lg font-semibold flex items-center gap-2 text-slate-800">
          <History className="w-5 h-5 text-slate-500" />
          Мои исследования
        </h2>
        
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <Input 
              placeholder="Поиск..." 
              className="pl-9 h-9 bg-slate-50 border-slate-200 text-sm shadow-none"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <Select value={sortOrder} onValueChange={setSortOrder}>
            <SelectTrigger className="w-[140px] h-9 bg-slate-50 text-sm border-slate-200 shadow-none">
              <div className="flex items-center gap-2 truncate">
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                <SelectValue placeholder="Сортировка" />
              </div>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Сначала новые</SelectItem>
              <SelectItem value="oldest">Сначала старые</SelectItem>
              <SelectItem value="priority">По приоритету</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="p-3 space-y-3">
          <AnimatePresence initial={false}>
            {sortedHistory.map((item) => {
              const priority = PRIORITY_MAP[item.priority];
              const status = STATUS_MAP[item.status];
              const StatusIcon = status.icon;

              return (
                <motion.div 
                  key={item.id} 
                  layout
                  initial={{ opacity: 0, y: 10, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95, height: 0, marginBottom: 0, padding: 0, overflow: 'hidden' }}
                  transition={{ duration: 0.2 }}
                  className={`relative flex flex-col gap-2 p-3 rounded-xl bg-white hover:shadow-md transition-all cursor-pointer border border-slate-200 border-l-4 ${priority.border} group`}
                >
                  <div className="flex justify-between items-start gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`w-2 h-2 rounded-full ${priority.dot} shrink-0`} title={priority.label} />
                        <h4 className="text-sm font-semibold text-slate-800 truncate group-hover:text-blue-600 transition-colors">
                          {item.title}
                        </h4>
                      </div>
                      <p className="text-xs text-slate-500 ml-4">{item.displayDate}</p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="h-7 w-7 text-slate-400 opacity-0 group-hover:opacity-100 hover:text-red-600 hover:bg-red-50 -mt-1 -mr-1 transition-all shrink-0"
                      onClick={(e) => { e.stopPropagation(); onDelete(item.id); }}
                      title="Удалить исследование"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex items-center justify-between mt-1 ml-4">
                    <Badge variant="outline" className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0 h-5 border ${status.color}`}>
                      <StatusIcon className="w-3 h-3 mr-1" />
                      {status.label}
                    </Badge>
                    <span className={`text-[10px] font-semibold ${priority.text}`}>
                      {priority.label}
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
          {sortedHistory.length === 0 && (
            <div className="text-center py-8 text-slate-500 text-sm">
              Исследования не найдены
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}

export default function App() {
  const [navPath, setNavPath] = useState<Category[]>([]);

  const currentCategoryChildren = useMemo(() => {
    if (navPath.length === 0) return ORGANS;
    const lastNode = navPath[navPath.length - 1];
    return lastNode.children;
  }, [navPath]);

  const handleSelectCategory = (category: Category) => {
    setNavPath((prev) => [...prev, category]);
  };

  const handleBack = () => {
    setNavPath((prev) => prev.slice(0, -1));
  };

  const handleReset = () => {
    setNavPath([]);
  };
  const [history, setHistory] = useState<HistoryItem[]>(INITIAL_HISTORY);
  const [sortOrder, setSortOrder] = useState("newest");

  const handleDelete = (id: number) => {
    setHistory(prev => prev.filter(item => item.id !== id));
  };

  return (
    <div className="flex h-screen w-full bg-slate-100 overflow-hidden font-sans">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block w-[340px] shrink-0 shadow-sm z-10">
        <HistoryPanel 
          history={history} 
          onDelete={handleDelete}
          sortOrder={sortOrder}
          setSortOrder={setSortOrder}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col h-full overflow-hidden relative">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 lg:px-8 shrink-0 shadow-sm z-10">
          <div className="flex items-center gap-3">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="lg:hidden -ml-2">
                  <Menu className="w-5 h-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="p-0 w-[340px]">
                <HistoryPanel 
                  history={history} 
                  onDelete={handleDelete}
                  sortOrder={sortOrder}
                  setSortOrder={setSortOrder}
                />
              </SheetContent>
            </Sheet>
            <h1 className="text-xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              MedAI Analysis
            </h1>
          </div>
          
          <Button className="hidden sm:flex gap-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full px-6 shadow-md hover:shadow-lg transition-all" onClick={handleReset}>
            <Plus className="w-4 h-4" />
            Новое исследование
          </Button>
        </header>

        {/* Workspace Area */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-8 relative">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-50/50 via-slate-100/20 to-slate-100/50 -z-10 pointer-events-none" />
          
          <div className="max-w-5xl mx-auto w-full h-full flex flex-col justify-start pt-8 lg:pt-16 min-h-[500px]">
            <AnimatePresence mode="wait">
              {currentCategoryChildren ? (
                <motion.div 
                  key={`selector-${navPath.length}`}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className="w-full"
                >
                  {navPath.length > 0 && (
                    <Button 
                      variant="ghost" 
                      onClick={handleBack}
                      className="mb-4 -ml-4 text-slate-500 hover:text-slate-800"
                    >
                      <ChevronRight className="w-4 h-4 mr-1 rotate-180" />
                      Назад
                    </Button>
                  )}

                  <div className="mb-8 pl-1">
                    {navPath.length > 0 && (
                      <div className="flex items-center gap-2 text-sm font-medium text-blue-600 mb-3">
                        Исследования 
                        {navPath.map((node, i) => (
                          <React.Fragment key={node.id}>
                            <ChevronRight className="w-4 h-4 text-slate-400" />
                            <span className={i === navPath.length - 1 ? "text-slate-800 font-semibold" : ""}>{node.name}</span>
                          </React.Fragment>
                        ))}
                      </div>
                    )}
                    <h2 className="text-2xl font-semibold text-slate-800 tracking-tight">
                      {navPath.length === 0 ? "Новое исследование" : navPath[navPath.length - 1].name}
                    </h2>
                    <p className="text-slate-500 mt-1.5">
                      {navPath.length === 0 ? "Выберите область загрузки снимков для автоматизированного анализа." : "Выберите подходящий тип исследования"}
                    </p>
                  </div>

                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
                    {currentCategoryChildren.map((organ, idx) => {
                      const Icon = organ.icon || FileText;
                      return (
                        <motion.button
                          key={organ.id}
                          onClick={() => handleSelectCategory(organ)}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.1, duration: 0.4 }}
                          whileHover={{ scale: 1.02, y: -2 }}
                          whileTap={{ scale: 0.98 }}
                          className="group relative flex flex-col items-start p-6 rounded-2xl bg-white border border-slate-200 hover:border-blue-300 shadow-sm hover:shadow-md transition-all duration-300 text-left w-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
                        >
                          <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-0 bg-blue-500 rounded-r-md group-hover:h-12 transition-all duration-300 ease-out" />
                          
                          <div className="w-12 h-12 rounded-xl bg-slate-100 flex items-center justify-center mb-4 text-slate-600 group-hover:bg-blue-50 group-hover:text-blue-600 transition-colors duration-300">
                            <Icon className="w-6 h-6" />
                          </div>
                          
                          <h3 className="text-lg font-semibold text-slate-800 tracking-tight group-hover:text-blue-700 transition-colors mb-1 leading-tight">
                            {organ.name}
                          </h3>
                          <p className="text-sm text-slate-500 group-hover:text-slate-600 transition-colors line-clamp-2">
                            {organ.desc}
                          </p>
                        </motion.button>
                      );
                    })}
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="upload"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="w-full max-w-2xl mx-auto"
                >
                  <Button 
                    variant="ghost" 
                    onClick={handleBack}
                    className="mb-6 -ml-4 text-slate-500 hover:text-slate-800"
                  >
                    <ChevronRight className="w-4 h-4 mr-2 rotate-180" />
                    Назад к выбору
                  </Button>

                  <Card className="border-2 border-dashed border-slate-200 bg-white shadow-sm rounded-3xl overflow-hidden">
                    <CardContent className="p-12 flex flex-col items-center justify-center text-center">
                      <div className="w-24 h-24 rounded-full bg-blue-50 flex items-center justify-center mb-6">
                        <Upload className="w-10 h-10 text-blue-500" />
                      </div>
                      <h3 className="text-2xl font-semibold text-slate-800 mb-3">
                        Загрузите снимки
                      </h3>
                      <p className="text-slate-500 mb-8 max-w-md">
                        Перетащите файлы <strong>{navPath[navPath.length - 1]?.name.toLowerCase()}</strong> сюда или нажмите кнопку для выбора на вашем устройстве.
                      </p>
                      <Button size="lg" className="rounded-full px-8 bg-blue-600 hover:bg-blue-700 shadow-md">
                        Выбрать файлы
                      </Button>
                      <p className="text-xs text-slate-400 mt-4">
                        Поддерживаемые форматы: DICOM, JPEG, PNG
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

          </div>
        </main>
      </div>
    </div>
  );
}
